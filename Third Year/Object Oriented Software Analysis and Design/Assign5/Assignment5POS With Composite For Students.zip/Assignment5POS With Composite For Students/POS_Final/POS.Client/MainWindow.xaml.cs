﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;
using POS.Model;

namespace POS.Client
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    /// 
    public partial class MainWindow : Window
    {
        private Store store;
        private DataTable items;

        public MainWindow()
        {
            InitializeComponent();
            store = new Store();
            items = new DataTable();
            items.Columns.Add("Name", typeof(String));
            items.Columns.Add("Quantiy", typeof(String));
            items.Columns.Add("Price", typeof(String));

            dgProduct.ItemsSource = items.DefaultView;

            store.getRegister().makeNewSale();
            items.Clear();
            tbTotal.Text = "0";

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            store.getRegister().enterltem(txtProduct.Text, Int32.Parse(txtQuatiy.Text));
            DataRow datarow = items.NewRow();
            datarow["Name"] = store.getRegister().GetProductCatalog().getSpecification(txtProduct.Text).getDescription();
            datarow["Quantiy"] = txtQuatiy.Text;
            datarow["Price"] = store.getRegister().GetProductCatalog().getSpecification(txtProduct.Text).getPrice().ToString();
            items.Rows.Add(datarow);

            //tbTotal.Text = store.getRegister().GetSale().getTotal().ToString();
            //Stragegy
            float totalAfterdiscount = store.getRegister().GetSale().getTotalAfterDiscouting();
            float totalTax = store.getRegister().GetSale().getTotalTax();
            float amount = totalAfterdiscount + totalTax;
            tbTotal.Text = amount.ToString();
            txtProduct.Text = "";
            txtQuatiy.Text = "";
          
        }

        private void btnMakeSale_Click(object sender, RoutedEventArgs e)
        {
            store.getRegister().makeNewSale();
            items.Clear();
            tbTotal.Text = "0";
        }

        private void btnMakePayment_Click(object sender, RoutedEventArgs e)
        {
            store.getRegister().makePayment(float.Parse(txtPaymentAmount.Text));
            tbBalance.Text = store.getRegister().GetSale().getBalance().ToString();
        }
    }

    public class ItemView
    {
        public String NO { get; set; }
        public String Item { get; set; }
    }
}
