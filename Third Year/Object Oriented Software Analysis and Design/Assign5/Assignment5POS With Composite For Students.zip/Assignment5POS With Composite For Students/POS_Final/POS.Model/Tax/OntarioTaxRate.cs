﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POS.Model
{
    public class OntarioTaxRate
    {
        public float GetOntarioTaxRate()
        {
            float taxRate;
            //Do lots of works to get tax rate
            taxRate = 0.13f;
            //........
            return taxRate;
        }
    }
}
