﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POS.Model
{
    public class QuebecTaxRate
    {
        public float GetQuebecTaxRate()
        {
            float taxRate;
            //Do lots of works to get tax rate
            taxRate = 0.15f;
            //........
            return taxRate;
        }
    }
}
