﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POS.Model
{
    public abstract class CompositePricingStrategy : ISalePricingStrategy
    {
        protected List<ISalePricingStrategy> strategies;

        public void Add(ISalePricingStrategy s)
        {
            strategies.Add(s);
        }
        public abstract float GetTotal(Sale sale);
       
    }
}
