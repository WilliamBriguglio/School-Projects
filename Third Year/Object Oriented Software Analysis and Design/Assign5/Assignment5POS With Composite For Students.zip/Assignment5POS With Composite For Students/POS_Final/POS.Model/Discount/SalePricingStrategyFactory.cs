﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POS.Model
{
    public class SalePricingStrategyFactory
    {
        public static ISalePricingStrategy CreateInstance()
        {
            DateTime dateTime =  DateTime.Now;
            if (dateTime.DayOfWeek == DayOfWeek.Saturday || dateTime.DayOfWeek == DayOfWeek.Sunday)
            {
                return new AbsoluteDiscountOverThresholdPricingStrategy();
            }
            else
            {
                return new PercentDiscountStrategy();
            }
        }
    }
}
