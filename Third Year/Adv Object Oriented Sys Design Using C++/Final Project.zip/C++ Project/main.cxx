//------------------------------------------------------------------------------
//
// This program runs a genetic algorithm for computing task/machine
// schedules.  It is mainly for testing the GA routine on subsequently
// larger and larger pool sizes to see how it compares when run
// serially vs multithreaded.
//
//------------------------------------------------------------------------------

#include "types.hxx"
#include "ga.hxx"
#include "program_options.hxx"

#include <random>
#include <chrono>
#include <iostream>
#include <thread>
#include <iomanip>

//------------------------------------------------------------------------------

int main(int argc, char* argv[])
{
  using namespace std;

  cs340::program_options args(argc, argv);
  
  //Iterator pointing to the first element of args.seeds 
  auto first = begin(args.seeds);
  
  //Iterator pointing to one past the end of the elements of args.seeds
  auto one_after_last = end(args.seeds);
  ++one_after_last;
  
  std::seed_seq seed(first, one_after_last);
  
  //Random number generator with the seed sequence
  cs340::random_generator engine(seed);

  //object of type cs340::simulation parameters
  cs340::simulation_parameters params { args.generations, args.min_pool_size, 
  						args.threads };

  auto matrix = cs340::create_random_matrix(args.tasks, args.machines, 30, engine);
  
  
  cout << "Pool\tResult\tTime (s)\n";
  for ( ;
    params.pool_size <= args.max_pool_size;
    params.pool_size += args.pool_size_step
  ) 
  {
    //Get the current CPU time. use std::chrono::high_resolution_clock.
    auto start_time = std::chrono::high_resolution_clock::now();
    
    //Call the function cs340::run_simulation and return the value of the 
    //function in the result variable.
    auto result = cs340::run_simulation(matrix, params, engine);
    
    //Get the current CPU time to mark end of simulation run.
    auto end_time = std::chrono::high_resolution_clock::now();

    //The difference between the stop time and start time.
    chrono::duration<double> simulation_time{end_time - start_time};

    //Output to standard out the following results.
    std::cout << params.pool_size
              << '\t'
	      << setprecision(6)
              << result.score(matrix)
	      << '\t'
	      << simulation_time.count()
	      << std::endl;
  }
}

//------------------------------------------------------------------------------
