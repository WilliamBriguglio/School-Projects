//------------------------------------------------------------------------------
//
// This file contains the implementation of the genetic algorithm simulation.
// There are many helper functions inside of an anonymous namespace. That
// ensures those functions have static linkage and are not visible outside
// of this translation unit.
//
// The helper functions all take in a random generator by reference. The
// reason for passing it in as a parameter instead of relying on a glboal
// RNG is to avoid having to lock the generator when it is being used in
// different threads. The way that these functions are written, each thread
// can have its own RNG (seeded appropriately BEFORE firing off the thread)
// without introducing data races and other nasty surprises.
//
//------------------------------------------------------------------------------

#include "ga.hxx"
#include "types.hxx"

#include <utility>
#include <random>
#include <vector>
#include <algorithm>
#include <numeric>
#include <cstddef>
#include <future>

using namespace std;

//------------------------------------------------------------------------------

namespace cs340 
{
  namespace 
  {
    // Special sorting function object to keeping our gene pools sorted.
    struct schedule_compare 
    {
      explicit schedule_compare(runtime_matrix const& m)
        : matrix_{m}
      { }

      // Function call operator overload that takes in two
      // const lvalue-references to schedule objects. The operator should
      // return true if the first schedule's score is greater than the
      // second schedule's.
      bool operator ()(schedule const& sch1, schedule const& sch2)
      {
                return (sch1.score(matrix_) > sch2.score(matrix_)) ? true : false;
	
      }

    private:
      runtime_matrix const& matrix_;
    };

    // Populate the gene pool with random values. Each machine in each
    // schedule has equal probability of occuring.
    auto populate_gene_pool(runtime_matrix const& matrix,
    
    size_t const pool_size, random_generator& gen)
    {
      // 1. Create a std::vector of schedules, and use the .reserve()
      // member function to reserve space for pool_size schedules.

      std::vector<schedule> schedules;
      
      //Increases schedules memory layout
      schedules.reserve(pool_size);
	
      // 2. Create a std::uniform_int_distribution to sample from. The
      // resulting objects should be of type size_t, and should fall
      // in the range [0, matrix.machines() - 1]. NOTE: This is an
      // INCLUSIVE range. <-- TAKE THIS INTO ACCOUNT!

      std::uniform_int_distribution<size_t> dist(0, matrix.machines() - 1);
	
      // 3. Using std::generate_n, fill the vector you created
      // with randomly generated schedules. Use a lambda
      // expression as the argument to generate_n. Within that
      // lambda expression, you should use a for-loop and the
      // .set_task_assignment() member function of the schedule
      // to fill the schedule with random data sampled from your
      // int distribution. (Remember to capture dist, gen, and matrix
      // by reference --not by value.)
	
      std::generate_n(std::back_inserter(schedules), pool_size, 
     		[&dist, &gen, &matrix]()  
		{			 	
		  schedule s(matrix.tasks());
		  	
			for(size_t i = 0; i < matrix.tasks(); ++i)
			    s.set_task_assignment(i, dist(gen));		
			
		return s;
		}
	);
 
      // 4. Sort your randomly generated pool of schedules. Use
      // std::stable_sort, passing in an object of type
      // schedule_compare as the custom comparison operator.

      std::stable_sort(schedules.begin(), schedules.end(), 
                                             schedule_compare(matrix));	
      return schedules;
    }

    // Crossing two schedules over involves selecting a random spot
    // in the first schedule, and copying everything from the
    // beginning to that spot into a new schedule. Everything after
    // that spot is taken from the second schedule. The result is a
    // new schedule that (hopefully) inherits some of the desirable
    // traits from the two parents.
    auto cross_over(schedule c1, schedule const& c2, random_generator& gen)
    {
      //Using a uniform_int_distribution toselect a random point in the 
      //range [0, c1.tasks() - 1]
      uniform_int_distribution<size_t> random_point(0, c1.tasks() - 1);

      //Select a random spot in the first schedule
      size_t const random_offset = random_point(gen);

      //Copy every element from c2, starting at the crossover point, to c1
      for(auto i = random_offset ; i < c1.tasks(); ++i)
      {
	c1.set_task_assignment(i, c2.task_assignment(i));
      }

      //Return new, modified c1
      return c1;
    }

    // Randomly change one of the task entries in the schedule.
    void mutate(runtime_matrix const& matrix, schedule& c,
        random_generator& gen)
    {
      //Pick a radom task in the schedule
      std::uniform_int_distribution<size_t> random_task(0, c.tasks() - 1);
      
      //Picking a random machine.
      std::uniform_int_distribution<size_t> random_machine(0, 
      						matrix.machines() - 1);
    
      //Set the task assignment for the selected machine.
      c.set_task_assignment(random_task(gen), random_machine(gen));
    }
	

    // Run through a single generation of the genetic algorithm.
    //
    // First we do crossover to create new schedules. Afterward we
    // perform random mutations to the genes already in the pool.
    //
    // ASSUMPTION: The gene pool is in sorted order before calling
    // this function. Each operation done that modifies or produces
    // a new schedule ensures that the sorting invariant is
    // upheld. But that means nothing at all if they aren't sorted
    // from the get-go. This sorting must happen in the calling code
    // because we explicitly want to avoid re-sorting the entire
    // pool every time a change is made.
    void run_single_generation(runtime_matrix const& matrix,
      vector<schedule>& gene_pool, random_generator& gen)
    {
      // Some sane defaults.
      size_t const min_max_crossovers{(gene_pool.size() / 2) + 1};
      size_t const min_max_mutations{(gene_pool.size() / 3) + 1};

      size_t const max_crossovers{min(size_t{10}, min_max_crossovers)};
      size_t const max_mutations{min(size_t{25}, min_max_mutations)};

      // Initialize the global distribtions.
      uniform_int_distribution<size_t> x_pairs_dist{0, max_crossovers};
      uniform_int_distribution<size_t> mut_dist{0, max_mutations};

      //Generate random amount of crossover pairs.
      auto const x_pairs_count = x_pairs_dist(gen);

      if(x_pairs_count > 0 && x_pairs_count < gene_pool.size())
      {	
        //Since we need to make space for the new schedules we will be 
	//generating, we create an iterator that is suitable to be passed
	//into the .erase() member function of the gene pool, such that the 
	//last N schedules will be removed, where N is the number of crossover
	//pairs.
	gene_pool.erase(gene_pool.end() - x_pairs_count, gene_pool.end());

        //Vector of type double containing the scores to sum over
        std::vector<double> totals;
		
	//Each schedule has a chance of being selected for crossover directly
	//proportional to its score. In order to efficiently select these 
	//schedules roulette-style, we sample a random real from the range
	//[0, SUM_OF_ALL_scores)
 	
	//Transform the range into a vector of scores
	std::transform(gene_pool.begin(), gene_pool.end(), 
		std::back_inserter(totals),
		[&matrix](auto const& schedule){
			return schedule.score(matrix);
		});
        
	//Compute partial sum of the totals vector
	std::partial_sum(totals.begin(), totals.end(),totals.begin());

        //We now select x_pairs_count pairs to cross over
        uniform_real_distribution<double> random_double(0,totals.back() - 1);

        //Loop that will execute x_pairs_count times.
        for( size_t i = 0 ; i < x_pairs_count; ++i)
	{
	  //Generating two random number from our range.
          auto r1 = random_double(gen);
	  auto r2 = random_double(gen);

          //Finding the first value in totals vector that is NOT LESS than the
	  //first random number we drew.
          auto first_value_notless_than_r1 = std::lower_bound(totals.begin(), 
	  						totals.end(),r1);
	  
	  //Finding the offset of the value found via first_value_notless_than_r1
          auto r1_offset = std::distance(totals.begin(),
	  					first_value_notless_than_r1);

          //Same thing as above, except for our second random number.
          auto first_value_notless_than_r2 = std::lower_bound(totals.begin(), 
	  						totals.end(),r2);
	  
	  //Same as above, except for our second random number.
	  auto r2_offset = std::distance(totals.begin(),
	  				first_value_notless_than_r2);

          //Finding iterators into the gene pool that corresponds to the two
	  //random values that we drew.
  	  auto r1_it = gene_pool.begin() + r1_offset;
  	  auto r2_it = gene_pool.begin() + r2_offset;

          // Create a new schedule object by calling cross_over with
          // the two schedules pointed to by your computed iterators.
	
	  auto new_schedule_object = cross_over(*r1_it, *r2_it ,gen);

          // We need to maintain our sorted invariant. Use std::lower_bound
          // with an object of type schedule_compare as your custom comparision
          // to probe the gene pool for the first schedule that is NOT GREATER
          // than the one we just created via crossover.

          auto it = std::lower_bound(gene_pool.begin(), gene_pool.end(), 
	  			new_schedule_object, schedule_compare(matrix));  

	  gene_pool.insert(it,new_schedule_object);
	}    
      }
	  
      // Crossover is complete. Now we do mutation. Start by generating
      // a random size_t from the mut_dist distribution. Call it num_mutations.

      size_t num_mutations = mut_dist(gen);

      uniform_int_distribution<size_t> m_sel_dist(0, gene_pool.size() - 1);
      
      for (size_t j{}; j < num_mutations; ++j) 
      {
        // Sample a solution to mutate from m_sel_dist. Do this by
        // first sampling the distribution, then using the fact that vector's
        // iterators are random access, find the corresponding solution
        // by adding the sampled value to begin(gene_pool).

        auto mutated_schedule = gene_pool.begin() + m_sel_dist(gen);

        // Now that we have the iterator to the schedule to mutate,
        // call the mutate function.

        mutate(matrix, *mutated_schedule, gen);

        // Compute the position in the mutated matrix to insert the 
	// crossed-over solution. First call lower_bound.
        // Store the resulting iterator in a variable called pos.

        auto pos = std::lower_bound(gene_pool.begin(), gene_pool.end(), 
			*mutated_schedule, schedule_compare(matrix));

	//Instead of calling insert, use the algorithm std::rotate
        //to change the position of the schedule you mutated.
         if(pos > mutated_schedule)
	   //Left Rotation.
	   std::rotate(mutated_schedule, mutated_schedule + 1, pos);
	 else
           //Right Rotation.
	   std::rotate(pos, mutated_schedule, mutated_schedule + 1);  
	}
    }

   // Run the simulation for a fixed number of generations. The
   // gene pool is taken in by reference just in case the updates
   // need to be seen in the calling code.
   //
   // Returns the best schedule seen.
   auto run_simulation_n_times(runtime_matrix const& matrix,
      vector<schedule>& gene_pool,
      size_t const num_generations,
      random_generator& gen,
      size_t const time_til_convergence = 30)
    {
      double best{};
      size_t how_long_unchanged{};
	
      if (gene_pool.empty()) return schedule{}; // Should never happen.
	
	for (size_t i{}; i < num_generations; ++i) {
        run_single_generation(matrix, gene_pool, gen);
        auto& best_schedule = gene_pool.front();

        if (best_schedule.score(matrix) > best) {
          best = best_schedule.score(matrix);
          how_long_unchanged = 0;
        }
        else
          ++how_long_unchanged;
        if (how_long_unchanged > time_til_convergence) break;
      }

      return gene_pool.front();
    }
}  


  schedule run_simulation(runtime_matrix const& matrix,
      simulation_parameters const& args,
      random_generator& gen)
  {
    // First we need to check the number of threads.
    // If the number of threads to use is less than 1, throw
    // a std::runtime_error exception.
    if(args.threads < 1) 
    {
        throw std::runtime_error("Cannot run on less than 1 thread");
    }

    // If the number of threads is 1, then we will run the
    // simulation without any complex future stuff. First,
    // write an if-statement to check of the number of threads is 1,
    // and if true, create a gene pool (by calling populate_gene_pool)
    // of size args.pool_size. Then call the function run_simulation_n_times
    // with that gene pool and return the result of that function call.
    else if(args.threads == 1)
    {
    	auto gene_pool_size = populate_gene_pool(matrix, args.pool_size, gen);	
	return run_simulation_n_times(matrix, gene_pool_size, args.generations, 
									gen);
    }

    // Otherwise, we're running multithreaded code.

    // Create a vector to hold objects of type future<schedule>. call it
    // future_winners. Each thread will run an independent pool of solutions
    // to the problem and return the best solution. This vector of future schedule
    // objects will hold the best schedule from each thread.

    else 
    {
        std::vector<future<schedule>> future_winners;
	
    // Each thread will get its own random number generator, seeded
    // by the random number generator in this main thread. 
    //
    // A uniform_int_distribution of size_t's, that samples from the range
    // [0, 100]. We will generate seeds from it for each thread.
     	
    std::uniform_int_distribution<size_t> dist(0, 100);

    for (size_t i{}; i < args.threads; ++i) 
    {
      // Vector of size_t objects to store the seeds.
      vector<size_t> seeds;
      
      //Populate the vector by sampling the distribution (dist) six times.
      for(int i = 0; i < 6; ++i)
            	seeds.push_back(dist(gen));

      //Now we push back into our vector of futures...
      future_winners.push_back(
        async(
          launch::async,
          // This lambda function will execute on a separate thread. We can safely
          // hold a reference to the arguments struct and the matrix since they
          // will be read from only. We move the seeds vector into the lambda
          // (this is a C++14 feature) since they will only be used in the lambda
          // body and nowhere else. This saves us a copy.
          //
          // The return result of the lambda is a schedule object. By passing this
          // lambda into std::async, it converts it into a std::future<schedule> 
	  // that we then store in our vector of future schedules.
          [&matrix, &args, seeds = move(seeds), i]() -> schedule 
          {
            // Turn the vector of seeds into a std::seed_seq by using
            // std::seed_seq's iterator constructor.
	    std::seed_seq seed(seeds.begin(), seeds.end());

            // Create a random_generator object for this thread.
            random_generator local_gen(seed);

            // Some constants to help us determine the size of
            // this thread's pool.
            bool const last_iteration{i == args.threads - 1};
            bool const even_split{args.pool_size % args.threads == 0};
            size_t const pool_size
            {
              !last_iteration || even_split
                ? args.pool_size / args.threads
                : args.pool_size % args.threads
            };

            // Create a gene pool for this thread by calling
            // populate_gene_pool. Pass in the constant pool_size as the
            // pool size to create. Pass in the random generator that you created
            // for this thread as the generator.

            auto thread_gene_pool = populate_gene_pool(matrix,pool_size,local_gen);

            // Call run_simulation_n_times with this thread's pool and
            // this thread's random generator. Return the result of 
	    // run_simulation_n_times.
            return run_simulation_n_times(matrix,thread_gene_pool,
	    					args.generations, local_gen); 
          }
        )
      );
    }

    // Now we need to collect the schedules from our threads.
    schedule best{};

    // A range-based for-loop over the vector of future winning schedules.
    // Inside the loop body, create an rvalue-reference to the winning schedule
    // corresponding to the current future. Use the future schedule's .get()
    // member function to access this. Then, using the schedule_compare object,
    // if this schedule is better than the current best one, assign the best one
    // to the rvalue-reference to the schedule (using std::move).

	for(auto& i : future_winners)
	{
	  auto current_winning = schedule_compare(matrix);
	  auto fsched = std::move(i.get());
	  if(current_winning(fsched, best))
	  {
	  	best = std::move(fsched);
	  }
	}

    // We now have the best schedule of the best schedules. Return it!

    return best;
  }
 }
}
//-----------------------------------------------------------------------------
